<?php

use yii\helpers\Html;
use kartik\grid\GridView;
use yii\helpers\ArrayHelper;
use kartik\editable\Editable;

/* @var $this yii\web\View */
/* @var $model app\models\Country */

$this->title = Yii::t('app', 'List of Job Vacancies');
$this->params['breadcrumbs'][] = Yii::t('app', 'Employee');
$this->params['breadcrumbs'][] = Yii::t('app', 'Recruitment and Onboarding');
$this->params['breadcrumbs'][] = $this->title;

?>

<?= Yii::$app->session->getFlash('msg') ?>
  <div class="col-xs-12">
  <div class="col-lg-4 col-sm-4 col-xs-12 no-padding edusecArLangCss"><h3 class="box-title"><i class="fa fa-th-list"></i> 
    <?php echo "List of Job Vacancies" ?></h3></div>
      <div class="col-lg-4 col-sm-4 col-xs-12 no-padding" style="padding-top: 20px !important;">
     <div class="col-xs-4 left-padding edusecArLangHide">
       
     </div>
      <div class="col-xs-4 left-padding">
        <?= Html::a(Yii::t('academics', 'PDF'), ['export-data/export-to-pdf', 'model'=>get_class($searchModel)], ['class' => 'btn btn-block btn-warning', 'target'=>'_blank']) ?>
      </div>
       <div class="col-xs-4 left-padding">
        <?= Html::a(Yii::t('academics', 'EXCEL'), ['export-data/export-excel', 'model'=>get_class($searchModel)], ['class' => 'btn btn-block btn-primary', 'target'=>'_blank']) ?>
       </div>
       </div>
</div>

<div class="col-xs-12" style="padding-top: 10px;">
    <div class="box">
       <div class="box-header">
<style>
.truncate {
   max-width: 200px !important;
   overflow: hidden;
   white-space: nowrap;
   text-overflow: ellipsis;
}

.truncate:hover{
   overflow: visible;
   white-space: normal;
   width: auto;
}
</style>
       </div><!-- /.box-header -->
    <div class="box-body table-responsive">
     <div class="courseoutcome-index">
      
    
      <?= GridView::widget([
          'dataProvider' => $dataProvider,
          'filterModel' => $searchModel,
    'summary'=>'',
          'columns' => [

              ['class' => 'yii\grid\SerialColumn'],
[
      'label' => Yii::t('emp', 'Designation'),
      'attribute' => 'vacancy_jobrole',
      'value' => 'empMasterDesignation.emp_designation_name',
      'filter' => ArrayHelper::map(app\modules\employee\models\EmpDesignation::find()->where(['is_status' => 0 ])->all(),'emp_designation_id','emp_designation_name')
  
                ],
              'noofvacancies',
         
       
        ['label' => Yii::t('academics', 'Desired Qualification'),
          'attribute' => 'vacancy_desired_qualification',
          'value' => 'vacancy_desired_qualification',
          'contentOptions' => ['style'=>'max-width: 400px;','class' => 'truncate'],
          ],
         ['label' => Yii::t('mentor', 'Required Date'),
          'attribute' => 'required_date',
          'value' => function ($model, $key, $index, $widget) { 
                    return date("d-m-Y", strtotime($model->required_date));
                },
          'filter' => \yii\jui\DatePicker::widget([
                'model'=>$searchModel,
                'attribute'=>'required_date',
                'clientOptions' =>[
                    'dateFormat' => 'dd-mm-yyyy',
                    'changeMonth'=> true,
                    'changeYear'=> true,
        'defaultValue'=>null,
        'yearRange'=>'1900:'.(date('Y')+1),
        'defaultDate'=> null,],
           'options'=>[
        'id' => 'required_date',
                    'value' => NULL,
        'class'=>'form-control',
                     ],
            ]),
      'format' => 'html',
           
            ],
        [
    'class'=>'kartik\grid\EditableColumn',
    'attribute'=>'advt_published_at',
    //'format' => 'raw',
    'value' => 'advt_published_at',
    'readonly'=>function($model, $key, $index, $widget) {
      if(Yii::$app->user->can('/employee/recruitment/record')) {
        return false;
      }
      else
      return true;
               },
    'editableOptions'=>[
        'header'=>'Advertisement Published in',
        'formOptions' => ['action' => ['advtpublish']],
        'asPopover' => true,
        'inputType' => Editable::INPUT_TEXTAREA,
        'format' => Editable::FORMAT_BUTTON,
        'submitOnEnter' => false,
        //'size'=>'lg',
        'options' => ['class'=>'form-control', 'rows'=>5,'placeholder'=>'Newspaper, Website etc.']
    ],
    'hAlign'=>'left',
    'vAlign'=>'middle',
    'width'=>'50%',
   
],


       [
         'class' => 'yii\grid\ActionColumn', 'template'=>'{report} {refer}', 'buttons'=> [ 
          'report'=> function($url,$model) {


                    return Html::a( '<span class="glyphicon glyphicon-list-alt" title="Candidate Report"></span>', $url);



                },
          'refer'=> function($url,$model) {


                    return Html::a( '<span class="glyphicon glyphicon-hand-left" title="Refer a Candidate"></span>', $url, ['class' => 'view', 'data-pjax' => '0']);



                },
                ],
        ],
          ],
      ]); ?> 
       </div>
     </div>
  </div>
</div>
<?php
$this->registerJs(
  "$(document).on('ready pjax:success', function() {  // 'pjax:success' use if you have used pjax
    $('.view').click(function(e){
       e.preventDefault();      
       $('#pModal').modal('show')
                  .find('.modal-content')
                  .load($(this).attr('href'));  
   });
});
");

 yii\bootstrap\Modal::begin([
    'id'=>'pModal',
]);
 yii\bootstrap\Modal::end();
 ?>