<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\modules\student\models\StuGuardians */

$this->title = Yii::t('stu', 'Add Treatment Details : ') . ' ' .$model->empMasterEmpInfo->emp_title.' '. $model->empMasterEmpInfo->emp_first_name.' '.$model->empMasterEmpInfo->emp_middle_name.' '.$model->empMasterEmpInfo->emp_last_name;
$this->params['breadcrumbs'][] = ['label' => Yii::t('stu', 'Employee'), 'url' => ['default/index']];
$this->params['breadcrumbs'][] = ['label' => Yii::t('stu', 'Manage Employees'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->empMasterEmpInfo->emp_title.' '. $model->empMasterEmpInfo->emp_first_name.' '.$model->empMasterEmpInfo->emp_middle_name.' '.$model->empMasterEmpInfo->emp_last_name, 'url' => ['view', 'id' => $model->emp_master_id]];
$this->params['breadcrumbs'][] = $this->title;
?>


<div class="col-xs-12 col-sm-12">
	<div class="col-lg-8 col-sm-8 col-xs-12 no-padding edusecArLangCss">
		<h3 class="box-title">
			<i class="fa fa-user-md"></i> <?= Html::encode($this->title) ?>
		</h3>
	</div>
	<div class="col-lg-4 col-sm-4 col-xs-12 no-padding" style="padding-top: 20px !important;">
		<div class="col-xs-4 edusecArLangHide"></div>
		<div class="col-xs-4 edusecArLangHide"></div>
		<div class="col-xs-4 left-padding">
				<?= Html::a(Yii::t('stu', 'Back'), '', ['class' => 'btn btn-back btn-block', 'onclick'=>'js:history.go(-1);return false;']) ?>
		</div> 
	</div>
</div>

<div class="stu-guardians-create">
    <?= $this->render('emp_health', [
        'model' => $model, 'health' => $health,
    ]) ?>
</div>
