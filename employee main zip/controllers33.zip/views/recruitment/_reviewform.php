<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
use kartik\grid\GridView;
use kartik\editable\Editable;
use app\modules\employee\models\Vacancycreaterecommender;
use app\modules\employee\models\VacancycreaterecommenderSearch;
/* @var $this yii\web\View */
/* @var $model app\modules\academics\models\Subjectteacher */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="col-xs-12 col-lg-12">
  <div class="<?php echo $model->isNewRecord ? 'box-success' : 'box-info'; ?> box view-item col-xs-12 col-lg-12">
<div class="leaveapply-form">
  <?php
   $action = ['forward'];
  
  

$provider = new \yii\data\ActiveDataProvider([
    'query' => Vacancycreaterecommender::find()->where(['vacancy_master_id'=>$model->vacancy_id])->orderBy(['(v_id)' => SORT_DESC]),
    'pagination' => [
        'pageSize' => 50,
    ],
]);


?>
<?php 
$xcheckimmediateofficer = app\modules\employee\models\Vacancycreaterecommender::find()->where([ 'is_status'=> 0, 'forwarded_by'=>Yii::$app->getid->getId(),'vacancy_master_id'=>$model->vacancy_id])->one();

    if (isset($xcheckimmediateofficer)){

        if(count($xcheckimmediateofficer)>0) { 

          

$form = ActiveForm::begin([
            'id' => 'leaveapply-form',
            'action' => $action,
            'enableAjaxValidation' => true,
                ]); ?>

     
                 
<?= $form->field($model, 'v_id')->hiddenInput(['value'=> $xcheckimmediateofficer->v_id])->label(false);?>
<?= $form->field($model, 'vacancy_master_id')->hiddenInput(['value'=> $model->vacancy_id])->label(false);?>
<?= $form->field($model, 'entry_by_hr')->hiddenInput(['value'=> '0'])->label(false);?>
<div class="col-xs-12 col-lg-12 no-padding">
    <div class="col-sm-3">
         <?php echo $form->field($model,'forwarded_to',['inputOptions'=>[ 'class'=>'form-control'] ])->dropDownList(ArrayHelper::map(\app\modules\employee\models\EmpInfo::find()->joinWith('empMastersagain')->orderBy(['(emp_first_name)' => SORT_ASC])->all(),'empMastersagain.emp_master_user_id',function($model, $defaultValue) {
        return $model['emp_first_name'].' '.$model['emp_middle_name'].' '.$model['emp_last_name'];
    }),
            [
                    'prompt'=> Yii::t('academics', '--- Select Employee ---'),
                  
                ]       
                )->label('Forward To'); 
                ?>
    </div>
   
   
    <div class="col-sm-9">
        <?= $form->field($model, 'forwarder_remarks',['inputOptions'=>[ 'class'=>'form-control', 'placeholder'=>Yii::t('academics', 'Remarks')] ])->textInput(['maxlength' => 200])->label('Remarks if Any'); ?>
    </div>
 
</div>
    <div class="form-group col-xs-12 col-sm-12 col-lg-6 no-padding edusecArLangCss">
    <div class="col-xs-4">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('academics', 'Apply') : Yii::t('academics', 'Update'), ['class' => $model->isNewRecord  ? 'btn btn-block btn-success' : 'btn btn-block btn-info']) ?>
    </div>

    <div class="col-xs-4">
    <?= Html::a(Yii::t('academics', 'Dissaprove'), ['delete', 'id' => $xcheckimmediateofficer->v_id, 'vid' => $model->vacancy_id], [
            'class' => 'btn btn-block btn-danger',
            'data' => [
                'confirm' => Yii::t('academics', 'Are you sure you want to dissaprove this application?'),
                'method' => 'post',
            ],
        ]) ?> 
    </div>
    <?php
   if(Yii::$app->user->can('/employee/recruitment/record') ) {
    ?>
    <div class="col-xs-4">
    <?= Html::a(Yii::t('academics', 'HR::Finish Processing'), ['record', 'id' => $xcheckimmediateofficer->v_id, 'vid' => $model->vacancy_id], [
            'class' => 'btn btn-default btn-block',
            'data' => [
                'confirm' => Yii::t('academics', 'Are you sure you want to close this application as approved?'),
                'method' => 'post',
            ],
        ]) ?> 
    </div>
<?php
}
?>

     </div>
      <?php ActiveForm::end(); ?>
<?php
}
}
?>
   
<div class="col-xs-12" style="padding-top: 10px;">
    <div class="box">
       <div class="box-header">
<style>
.truncate {
   max-width: 200px !important;
   overflow: hidden;
   white-space: nowrap;
   text-overflow: ellipsis;
}

.truncate:hover{
   overflow: visible;
   white-space: normal;
   width: auto;
}
</style>
       </div><!-- /.box-header -->
    <div class="box-body table-responsive">
     <div class="facultybooks-index">
      
<?= GridView::widget([
          'dataProvider' => $provider,
          //'filterModel' => $searchModel,
          'summary'=>'',
          'columns' => [
              ['class' => 'yii\grid\SerialColumn'],
           [
          'attribute' => 'forwarded_by',
          'value' => function ($model) {                      
        return $model->facultymentorBy->emp_first_name.' '.$model->facultymentorBy->emp_middle_name.' '.$model->facultymentorBy->emp_last_name;
    },
 
            ],
        
          [
          'attribute' => 'forwarded_to',
          'value' => function ($model) {
          if (isset($model->facultymentorxBy)){                      
        return $model->facultymentorxBy->emp_first_name.' '.$model->facultymentorxBy->emp_middle_name.' '.$model->facultymentorxBy->emp_last_name;
      }
       else {                      
        return '-';
      }
    },
          ],
          

          [
          'label' => Yii::t('mentor', 'Remarks'),
          'attribute' => 'forwarder_remarks',
          'value' => 'forwarder_remarks',
          'contentOptions' => ['style'=>'max-width: 400px;','class' => 'truncate'],
          ],
           [
          'label' => Yii::t('mentor', 'Date and Time'),
          'attribute' => 'created_at',
          'value' => function ($model, $key, $index, $widget) { 
            if ($model->created_at <> '0000-00-00 00:00:00'){
                    return date("d-m-Y h:m:s", strtotime($model->created_at));}
            else {return '-';}
                },
          ],
         
          ['label' => Yii::t('academics', 'Status'),
          'attribute' => 'is_status',
          'format' => 'raw',
          'value' => function ($model) {if ($model->is_status=='1' or $model->is_status=='3'){return '<i class="fa fa-thumbs-up" aria-hidden="true" style="color:green"></i>';}
          else if ($model->is_status=='0'){return '<i class="fa fa-spinner" aria-hidden="true"></i>';}
          else if ($model->is_status=='2'){return '<i class="fa fa-thumbs-down" aria-hidden="true" style="color:red"></i>';}
          else {return 'Status Unknown';}
            },
          ],
            
        [
         'class' => 'app\components\CustomActionColumn', 'template'=>'', 'buttons'=> [],
        ],
          ],
      ]); ?>
    
       
       </div>
     </div>
  </div>
</div>

</div>
  </div>
</div>



