<?php
 use yii\helpers\Html;
 $emp=app\modules\employee\models\EmpMaster::findOne($_REQUEST['id']);
$adminUser = array_keys(\Yii::$app->authManager->getRolesByUser(Yii::$app->user->getId()));
if(isset($emp))
{
	$stu_health_record = new \yii\db\Query();
	$stu_health_record -> select('*')
	        ->from('dispensary dsp')
		->where(['dsp.patient_employee_user_id' => $emp->emp_master_user_id])->orderBy(['created_at'=>SORT_DESC]);

	$command = $stu_health_record->createCommand();
	
	
	
	if(Yii::$app->user->can('Doctor') OR $emp->emp_master_user_id == Yii::$app->getid->getId())
{
    
 $stu_data = $command->queryAll();   
}
else
{
    ?>
  <i class="fa fa-info-circle" style="color:red"></i> <font color="red">You are not authorized to view information on this page!</font>  
<?php
$stu_data = '';
}
}	
?>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<h2 class="page-header">
	<i class="fa fa-info-circle"></i> <?= Html::encode(Yii::t('stu', 'Health Report')) ?>
	<div class="<?= (Yii::$app->language == 'ar') ? 'pull-left' : 'pull-right'?>">
	<?php 
	if(Yii::$app->user->can('Doctor')) { ?>
		<?= Html::a('<i class="fa fa-stethoscope"></i> '. Yii::t('stu', 'New Treatment'), ['addtreatment', 'eid' => $model->emp_master_id], ['class' => 'btn-sm btn btn-primary text-warning', 'id' => 'update-guard-data']) ?>
	<?php } ?>
	</div>
	</h2>
  </div><!-- /.col -->
</div>



<?php

     if(!empty($stu_data))
     {
	$i = 1;
	foreach($stu_data as $sd)
	{
		if($sd['is_emg'] == 1)
			$check = true;
		else
			$check = false;
?>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<h2 class="page-header edusec-border-bottom-warning">
	<?= $i."# <i class='fa fa-hospital-o'></i> ".Yii::$app->formatter->asDate($sd['created_at'], 'dd-MM-yyyy h:i:s a')." by <i class='fa fa-user-md'></i> ".app\modules\employee\models\EmpInfo::findOne(app\modules\employee\models\EmpMaster::findOne(['emp_master_user_id'=>$sd['created_by']])->emp_master_emp_info_id)->emp_title." ".app\modules\employee\models\EmpInfo::findOne(app\modules\employee\models\EmpMaster::findOne(['emp_master_user_id'=>$sd['created_by']])->emp_master_emp_info_id)->emp_first_name." ".app\modules\employee\models\EmpInfo::findOne(app\modules\employee\models\EmpMaster::findOne(['emp_master_user_id'=>$sd['created_by']])->emp_master_emp_info_id)->emp_middle_name." ".app\modules\employee\models\EmpInfo::findOne(app\modules\employee\models\EmpMaster::findOne(['emp_master_user_id'=>$sd['created_by']])->emp_master_emp_info_id)->emp_last_name ?>
	<div class="<?= (Yii::$app->language == 'ar') ? 'pull-left' : 'pull-right'?>">
	
	        </div>
	</h2>
  </div><!-- /.col -->
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="<?= (Yii::$app->language == 'ar') ? 'pull-left' : 'pull-right'?> edusec-stu-emg-gur">
		<span class="edusec-emg-ct-label"><?php echo Yii::t('stu', 'Is Emergency'); ?></span>
		<?php 
		echo (($sd['is_emg'] == 1) ? "<span class='label label-danger'>".Yii::t('stu','Yes')."</span>" : "<span class='label label-success'>".Yii::t('stu','No')."</span>");
		?>
        </div>
  </div><!-- /.col -->
</div>

<div class="row">
	  <div class="col-lg-12 col-sm-12 col-xs-12">
		<div class="col-lg-3 col-sm-3 col-xs-6 edusec-profile-label edusecArLangCss"><?= $health->getAttributeLabel('complaint') ?></div>
		<div class="col-lg-9 col-sm-9 col-xs-6 edusec-profile-text"><?= $sd['complaint'] ?></div>
	  </div>

	<div class="col-md-12 col-xs-12 col-sm-12">
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $health->getAttributeLabel('bp') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= $sd['bp'] ?></div>
	  </div>
	  <div class="col-lg-6 col-sm-6 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $health->getAttributeLabel('pulse') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= $sd['pulse'] ?></div>
	  </div>
	</div>

    <div class="col-lg-12 col-sm-12 col-xs-12">
		<div class="col-lg-3 col-sm-3 col-xs-6 edusec-profile-label edusecArLangCss"><?= $health->getAttributeLabel('observation') ?></div>
		<div class="col-lg-9 col-sm-9 col-xs-6 edusec-profile-text"><?= $sd['observation'] ?></div>
	  </div>
    <div class="col-lg-12 col-sm-12 col-xs-12">
		<div class="col-lg-3 col-sm-3 col-xs-6 edusec-profile-label edusecArLangCss"><?= $health->getAttributeLabel('management') ?></div>
		<div class="col-lg-9 col-sm-9 col-xs-6 edusec-profile-text"><?= $sd['management'] ?></div>
	  </div>
	  
<div class="col-lg-12 col-sm-12 col-xs-12">
		<div class="col-lg-3 col-sm-3 col-xs-6 edusec-profile-label edusecArLangCss"><?= $health->getAttributeLabel('advise') ?></div>
		<div class="col-lg-9 col-sm-9 col-xs-6 edusec-profile-text"><?= $sd['advise'] ?></div>
	  </div>


</div>
<?php
	$i++;
	}
    }
    else
    {
?>
<table width="100%" cellpadding="0" cellspacing="0" class="table table-striped table-bordered table-hover table-responsive">
	<tr>
		<th class="table-cell-title text-center" colspan = 4><?= Yii::t("stu", "No Data Available") ?></th>
	</tr>
</table>
<?php
    }
?>
