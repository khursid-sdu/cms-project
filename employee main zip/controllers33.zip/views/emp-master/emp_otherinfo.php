<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\jui\DatePicker;
use yii\helpers\Url;
use app\models\Languages;
use app\models\Hobbies;
use kartik\widgets\Select2;
$empSession =  Yii::$app->session->get('emp_id');
$admin = array_keys(Yii::$app->AuthManager->getRolesByUser(Yii::$app->user->id) );
$role = Yii::$app->AuthManager->getRoles();
/* @var $this yii\web\View */
/* @var $model app\modules\student\models\StuMaster */

$this->title = Yii::t('emp', 'Update : ') . ' ' . $model->empMasterEmpInfo->emp_first_name." ".$model->empMasterEmpInfo->emp_last_name;
$this->params['breadcrumbs'][] = ['label' => Yii::t('emp', 'Employee'), 'url' => ['default/index']];
$this->params['breadcrumbs'][] = ['label' => Yii::t('emp', 'Manage Employees'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->empMasterEmpInfo->emp_first_name." ".$model->empMasterEmpInfo->emp_last_name, 'url' => ['view', 'id' => $model->emp_master_id]];
$this->params['breadcrumbs'][] = Yii::t('emp', 'Update Other Details');
?>
<div class="col-xs-12">
  <div class="col-lg-4 col-sm-4 col-xs-12 no-padding edusecArLangCss"><h3 class="box-title"><i class="fa fa-edit"></i> <?= Html::encode($this->title) ?></h3>
  </div>
    <div class="col-lg-4 col-sm-4 col-xs-12 no-padding" style="padding-top: 20px !important;">
	<div class="col-xs-4 edusecArLangHide"></div>
	<div class="col-xs-4 edusecArLangHide"></div>
	<div class="col-xs-4 left-padding">
	<?= Html::a(Yii::t('emp', 'Back'), ['index'], ['class' => 'btn btn-block btn-back']) ?>
	</div>
    </div>
 </div>

<div class="col-xs-12 col-lg-12">
  <div class="<?php echo $model->isNewRecord ? 'box-success' : 'box-info'; ?> box view-item col-xs-12 col-lg-12">

<div class="emp-master-update">
   
<?php $form = ActiveForm::begin(['id' => 'emp-otherinfo-update']); ?>

<div class="box box-solid box-info col-xs-12 col-lg-12 no-padding edusec-form-bg">
   <div class="box-header with-border">
       <h4 class="box-title"><i class="fa fa-info-circle"></i> <?php echo Yii::t('emp', 'Other Info'); ?></h4>
   </div>
   <?php if(Yii::$app->user->can("/employee/emp-master/update") && (Yii::$app->session->get('emp_id') == $_REQUEST['empid']) || in_array('SuperAdmin',$admin) || Yii::$app->user->can("updateAllEmpInfo") || ($model->emp_master_user_id == Yii::$app->getid->getId())) 
		{ ?>
   <div class="box-body">
       <div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-4 col-xs-12">
		    <?= $form->field($info, 'university_regd_no')->textInput(['maxlength' => 16]) ?>
		</div>
		
		
	</div>
	
	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-4 col-xs-12">
		    <?= $form->field($info, 'emp_aadhaar')->textInput(['maxlength' => 16]) ?>
		</div>
		<div class = "col-sm-4 col-xs-12">
		    <?= $form->field($info, 'emp_pan')->textInput(['maxlength' => 10]) ?>
		</div>
		<div class = "col-sm-4 col-xs-12">
		    <?= $form->field($info, 'emp_voter')->textInput(['maxlength' => 20]) ?>
		</div>
		
	</div>
	
	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-4 col-xs-12">
		    <?= $form->field($info, 'driving_license')->textInput(['maxlength' => 50]) ?>
		</div>
		
		
	</div>

<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-4 col-xs-12">
		    <?= $form->field($info, 'emp_bankaccount_no')->textInput(['maxlength' => 50]) ?>
		</div>
		<div class = "col-sm-4 col-xs-12">
		    <?= $form->field($info, 'emp_bankname')->textInput(['maxlength' => 100]) ?>
		</div>
		<div class = "col-sm-4 col-xs-12">
		    <?= $form->field($info, 'emp_ifsc')->textInput(['maxlength' => 30]) ?>
		</div>
		
	</div>

	<div class = "col-xs-12 col-sm-12 col-lg-12">
		<div class = "col-sm-6 col-xs-12">
		    <?= $form->field($info, 'emp_mother_name')->textInput(['maxlength' => 200]) ?>
		</div>
		<div class = "col-sm-6 col-xs-12">
		    <?= $form->field($info, 'emp_reference')->textInput(['maxlength' => 200]) ?>
		</div>
	</div>

	<div class ="col-xs-12 col-sm-12 col-lg-12">
		<div class = "col-sm-6 col-xs-12">
		    
		</div>
		<div class = "col-sm-6 col-xs-12">
	    	
		</div>
	</div>
	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-12 col-xs-12">
		 
		  <?= $form->field($info, 'emp_qualification')->widget(\yii\redactor\widgets\Redactor::className(),[
'clientOptions' => [
        'imageManagerJson' => ['/redactor/upload/image-json'],
        'imageUpload' => ['/redactor/upload/image'],
        'fileUpload' => ['/redactor/upload/file'],
        'lang' => 'en',
        'plugins' => ['clips', 'fontcolor','imagemanager']
    ],
]
  ) ?>
		</div>
	</div>
	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-12 col-xs-12">
		 
		 <?= $form->field($info, 'emp_specialization')->widget(\yii\redactor\widgets\Redactor::className(),[
'clientOptions' => [
        'imageManagerJson' => ['/redactor/upload/image-json'],
        'imageUpload' => ['/redactor/upload/image'],
        'fileUpload' => ['/redactor/upload/file'],
        'lang' => 'en',
        'plugins' => ['clips', 'fontcolor','imagemanager']
    ],
]
  ) ?>
		</div>
	</div>
	
	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-12 col-xs-12">
		 <?php $data = ArrayHelper::map(Languages::find()->asArray()->all(), 'language_name', 'language_name');
			foreach($data as $d)
				 $langss[]=$d;

			echo $form->field($info, 'emp_languages')->widget(Select2::classname(),[
			    'name' => 'emp_languages[]',
			    'options' => ['placeholder' => ''],
			    'pluginOptions' => [
				'tags' => $langss,
				'maximumInputLength' => 10,
				'multiple' => true
			    ],
			]);
		?> 
		</div>
	</div>

	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-12 col-xs-12">
		  
		  <?php $datah = ArrayHelper::map(Hobbies::find()->asArray()->all(), 'hobby_name', 'hobby_name');
  foreach($datah as $dh)
    $hobbyss[]=$dh;

  echo $form->field($info, 'emp_hobbies')->widget(Select2::classname(),[
      'name' => 'emp_hobbies[]',
      'options' => ['placeholder' => ''],
      'pluginOptions' => [
        'tags' => $hobbyss,
        'maximumInputLength' => 10,
        'multiple' => true
      ],
    ])->label('My Hobbies ...'); 
  ?>
		</div>
	</div>

	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-12 col-xs-12">
		  
		   <?= $form->field($info, 'emp_bookswritten')->widget(\yii\redactor\widgets\Redactor::className(),[
'clientOptions' => [
        'imageManagerJson' => ['/redactor/upload/image-json'],
        'imageUpload' => ['/redactor/upload/image'],
        'fileUpload' => ['/redactor/upload/file'],
        'lang' => 'en',
        'plugins' => ['clips', 'fontcolor','imagemanager']
    ],
]
  ) ?>
		</div>
	</div>
	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-12 col-xs-12">
		  
		  <?= $form->field($info, 'emp_rndprojects')->widget(\yii\redactor\widgets\Redactor::className(),[
'clientOptions' => [
        'imageManagerJson' => ['/redactor/upload/image-json'],
        'imageUpload' => ['/redactor/upload/image'],
        'fileUpload' => ['/redactor/upload/file'],
        'lang' => 'en',
        'plugins' => ['clips', 'fontcolor','imagemanager']
    ],
]
  ) ?>
		</div>
	</div>
	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-12 col-xs-12">
		  
		   <?= $form->field($info, 'emp_membership')->widget(\yii\redactor\widgets\Redactor::className(),[
'clientOptions' => [
        'imageManagerJson' => ['/redactor/upload/image-json'],
        'imageUpload' => ['/redactor/upload/image'],
        'fileUpload' => ['/redactor/upload/file'],
        'lang' => 'en',
        'plugins' => ['clips', 'fontcolor','imagemanager']
    ],
]
  ) ?>
		</div>
	</div>
	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-12 col-xs-12">
		  
		  <?= $form->field($info, 'emp_workshops')->widget(\yii\redactor\widgets\Redactor::className(),[
'clientOptions' => [
        'imageManagerJson' => ['/redactor/upload/image-json'],
        'imageUpload' => ['/redactor/upload/image'],
        'fileUpload' => ['/redactor/upload/file'],
        'lang' => 'en',
        'plugins' => ['clips', 'fontcolor','imagemanager']
    ],
]
  ) ?>
		</div>
	</div>
	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-12 col-xs-12">
		  
		  <?= $form->field($info, 'emp_national_conferences')->widget(\yii\redactor\widgets\Redactor::className(),[
'clientOptions' => [
        'imageManagerJson' => ['/redactor/upload/image-json'],
        'imageUpload' => ['/redactor/upload/image'],
        'fileUpload' => ['/redactor/upload/file'],
        'lang' => 'en',
        'plugins' => ['clips', 'fontcolor','imagemanager']
    ],
]
  ) ?>
		</div>
	</div>
	<div class="col-xs-12 col-lg-12 col-lg-12">
		<div class = "col-sm-12 col-xs-12">
			<?= $form->field($info, 'emp_international_conferences')->widget(\yii\redactor\widgets\Redactor::className(),[
'clientOptions' => [
        'imageManagerJson' => ['/redactor/upload/image-json'],
        'imageUpload' => ['/redactor/upload/image'],
        'fileUpload' => ['/redactor/upload/file'],
        'lang' => 'en',
        'plugins' => ['clips', 'fontcolor','imagemanager']
    ],
]
  ) ?>
		  
		</div>
	</div>

</div><!---./end box-body--->
</div><!---./end box--->
 
    <div class="form-group col-xs-12 col-sm-6 col-lg-4 no-padding edusecArLangCss">
	<div class="col-xs-6 col-xs-12">
	    <?= Html::submitButton($model->isNewRecord ? Yii::t('emp', 'Create') : Yii::t('emp', 'Update'), ['class' => $info->isNewRecord  ? 'btn btn-block btn-success' : 'btn btn-block btn-info']) ?>
	</div>
	<div class="col-xs-6">
	    <?= Html::a(Yii::t('emp', 'Cancel'), ['view', 'id' => $model->emp_master_id], ['class' => 'btn btn-default btn-block']); ?>
	</div>
    </div>	

    <?php ActiveForm::end(); ?>
 <?php
}
else
{
echo "<font color='red'>Permission Denied.</font>";
}
    ?>
</div></div></div>
