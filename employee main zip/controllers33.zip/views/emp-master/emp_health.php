<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $guard app\modules\student\models\StuGuardians */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="col-xs-12 col-lg-12">
  <div class="<?php echo $health->isNewRecord ? 'box-success' : 'box-info'; ?> box view-item col-xs-12 col-lg-12">
   <div class="emp-health-form">
    <?php $form = ActiveForm::begin([
			'id' => 'emp-health-form',
			'fieldConfig' => [
			    'template' => "{label}{input}{error}",
			],
    ]); ?>

   <div class="col-xs-12 col-sm-12 col-lg-12 no-padding">
    <div class="col-xs-12 col-sm-12 col-lg-12">
    <?= $form->field($health, 'complaint')->textArea(['maxlength' => 5000]) ?>
    </div>

   </div>

   <div class="col-xs-12 col-sm-12 col-lg-12 no-padding">
      <div class="col-xs-12 col-sm-4 col-lg-4">
    <?= $form->field($health, 'bp')->textInput(['maxlength' => 7]) ?>
    </div>
    
    <div class="col-xs-12 col-sm-4 col-lg-4">
    <?= $form->field($health, 'pulse')->textInput(['maxlength' => 3]) ?>
    </div>
    
    <div class="col-xs-12 col-sm-4 col-lg-4">
    <?= $form->field($health, 'is_emg')->widget(kartik\widgets\SwitchInput::className(),
                [
            'model'=>$health,
            'name' => 'is_emg',
        'pluginOptions' => [
        'size' => 'large',
        'onColor' => 'danger',
        'offColor' => 'success',
        'onText' => 'Critical',
        'offText' => 'Normal',
        ],])->label('Patient Condition') ?>  
    </div>

   </div>

   <div class="col-xs-12 col-sm-12 col-lg-12 no-padding">
      <div class="col-xs-12 col-sm-12 col-lg-12">
    <?= $form->field($health, 'observation')->textArea(['maxlength' => 5000]) ?>
    </div>
    <div class="col-xs-12 col-sm-12 col-lg-12">
    <?= $form->field($health, 'management')->textArea(['maxlength' => 5000]) ?>
    </div>

    <div class="col-xs-12 col-sm-12 col-lg-12">
    <?= $form->field($health, 'advise')->textArea(['maxlength' => 5000]) ?>
    </div>
   </div>

   

   

    <div class="form-group col-xs-12 col-sm-6 col-lg-4 no-padding edusecArLangCss">
	<div class="col-xs-6">
        <?= Html::submitButton($health->isNewRecord ? Yii::t('stu', 'Add') : Yii::t('stu', 'Update'), ['class' => $health->isNewRecord  ? 'btn btn-block btn-success' : 'btn btn-block btn-info']) ?>
	</div>
	<div class="col-xs-6">
	    <?= Html::a(Yii::t('stu', 'Cancel'), ['emp-master/view', 'id' => $model->emp_master_id, '#' => 'health'], ['class' => 'btn btn-default btn-block']); ?>
	</div>
    </div>
    <?php ActiveForm::end(); ?>
   </div>
  </div>
</div>
