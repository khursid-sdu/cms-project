<?php
use yii\helpers\Html;
use kartik\grid\GridView;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
?>
<div class="stu-master-index">
    <?php  
	$org = app\models\Organization::find()->asArray()->one();
	$model->sort = false; 
	$dispColumn = false;
	if($type == 'Excel') {
		echo "<meta http-equiv=\"Content-type\" content=\"text/html;charset=utf-8\" />";
		echo "<table><tr> <th colspan='11'><h3>".$org['org_name']."</h3> </th> </tr> </table>";
		$dispColumn = true;
	}
    ?>
    <?= GridView::widget([
        'dataProvider' => $model,
        'layout' => '{items}',
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            
             [
			'label' => Yii::t('emp', 'Employee ID'),
			'attribute' => 'emp_unique_id',
			],
			
			[
			'label' => Yii::t('emp', 'Title'),
			'attribute' => 'emp_title',
			],
		[
			'label' => Yii::t('emp', 'First Name'),
			'attribute' => 'emp_first_name',
			],
		[
			'label' => Yii::t('emp', 'Middle Name'),
			'attribute' => 'emp_middle_name',
			],
		[
			'label' => Yii::t('emp', 'Last Name'),
			'attribute' => 'emp_last_name',
			],
 	        
 	        [
			'label' => Yii::t('emp', 'Department'),
			'attribute' => 'emp_master_department_id_temp',
			'value' => 'empDeptagain.emp_department_name',
		
                ],	
[
			'label' => Yii::t('emp', 'Designation'),
			'attribute' => 'emp_master_designation_id_temp',
			'value' => 'empDesignationagain.emp_designation_name',
		
	
                ],
           
            'emp_thumb',
            
            
       

            ['class' => 'yii\grid\ActionColumn','template'=>''],
        ],
    ]); ?>
</div>

