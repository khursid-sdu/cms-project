<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\jui\DatePicker;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\modules\student\models\StuMaster */
/*
*/

$referredtotal=\app\modules\employee\models\Vacancyrefer::find()->andWhere(['v_master'=>$model->vacancy_id, 'created_by'=>Yii::$app->getid->getId(),'is_status'=>0])->count();
if($referredtotal>0){
  $content="<font color='blue'>you have referred <b>".$referredtotal."</b> no. of candidate(s) for this vacancy. You are invited to refer more candidates.</font>";
}
else
{
  $content="<font color='red'>You have not referred any candidate for this vacancy. You are invited to refer your 1st candidate.</font>";
}
$this->title = Yii::t('stu', 'Refer a Candidate');
?>

<script>
$(document).ready(function(){
     $('input[type=file]').bootstrapFileInput();
});
</script>

<div class="col-xs-12 col-lg-12 no-padding">
  <div class="box-info box view-item col-xs-12 col-lg-12">
    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>

    <div class="col-lg-12 col-sm-12 col-xs-12 no-padding edusecArLangCss"><h3 class="box-title"><i class="fa fa-th-list"></i> <?= $this->title ?></h3><h5><?= $content ?></h5></div>
   <div class="stu-master-update">

    <?php $form = ActiveForm::begin([
      'id' => 'stu-master-update',
      'options' => ['enctype' => 'multipart/form-data'],
      'action' => ['view'],
      'enableAjaxValidation' => false,
      'fieldConfig' => [
          'template' => "{label}{input}{error}",
      ],  
    ]); ?>

   <div class="col-xs-12 col-sm-12 col-lg-12 no-padding">
   <div class="col-sm-12">
         <?php echo $form->field($model,'vacancy_jobrole',['inputOptions'=>[ 'class'=>'form-control'] ])->dropDownList(ArrayHelper::map(\app\modules\employee\models\EmpDesignation::find()->orderBy(['(emp_designation_name)' => SORT_ASC])->all(),'emp_designation_id','emp_designation_name'),array("disabled" => "disabled"),
            [
                    'prompt'=> Yii::t('academics', '--- Select ---'),
                  
                ]       
                ); 
                ?>
    </div>
    
   </div>

   <div class="col-xs-12 col-sm-12 col-lg-12 no-padding">
   <div class="col-sm-12">
    <?= $form->field($modelreferral, 'v_master')->hiddenInput(['value'=> $model->vacancy_id])->label(false); ?>
    <?= $form->field($modelreferral, 'c_name')->textInput() ?>
   </div>
   <div class="col-xs-12 col-sm-12 col-lg-12 no-padding">
   <div class="col-sm-6">
    <?= $form->field($modelreferral, 'c_mobile')->textInput() ?>
   </div>
   <div class="col-sm-6">
    <?= $form->field($modelreferral, 'c_aadhaar')->textInput() ?>
   </div> 
   </div>
   <div class="col-xs-12 col-sm-12 col-lg-12 no-padding">
   <div class="col-sm-12">
    <?= $form->field($modelreferral, 'resume')->fileInput(['title' => Yii::t('stu', 'Browse File')]) ?>
   </div>
 </div>

 <div class="col-xs-12 col-sm-12 col-lg-12 no-padding">
   <div class="col-sm-12">
    <hr>
   </div>
 </div>

    <div class="form-group col-xs-12 col-sm-6 col-lg-6 no-padding edusecArLangCss">
  <div class="col-xs-6 col-sm-6" style="<?= (Yii::$app->language == 'ar') ? 'float:none' : ''; ?>">
        <?= Html::submitButton($modelreferral->isNewRecord ? Yii::t('stu', 'Refer') : Yii::t('stu', 'Update'), ['class' => $modelreferral->isNewRecord  ? 'btn btn-block btn-success' : 'btn btn-block btn-info']) ?>
  </div>
  <!--div class="col-xs-6">
      <?php // Html::a('Cancel', ['view', 'id' => $model->stu_master_id], ['class' => 'btn btn-default btn-block']); ?>
  </div-->
    </div>

    <?php ActiveForm::end(); ?>
   </div>
  </div>
</div>
