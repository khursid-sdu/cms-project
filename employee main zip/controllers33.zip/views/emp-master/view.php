<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\grid\GridView;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
use app\assets_b\EduSecUserProfile;
EduSecUserProfile::register($this);
?>
<?php $empSession =  Yii::$app->session->get('emp_id');
$admin = array_keys(Yii::$app->AuthManager->getRolesByUser(Yii::$app->user->id) );
$role = Yii::$app->AuthManager->getRoles();
	

$this->title = $model->empMasterEmpInfo->emp_first_name." ".$model->empMasterEmpInfo->emp_last_name;
$this->params['breadcrumbs'][] = ['label' => Yii::t('emp', 'Employee'), 'url' => ['default/index']];
$this->params['breadcrumbs'][] = ['label' => Yii::t('emp', 'Manage Employees'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<!----------------------------------------------------------------------->
<section class="content-header">
<div class="row">
  <div class="col-xs-12">
	<h2 class="page-header">	
		<i class="fa fa-user"></i> <?php echo Yii::t('emp', 'Employee Profile'); ?>
		<div class="<?= (Yii::$app->language == 'ar') ? 'pull-left' : 'pull-right'; ?>">
		<?php if(Yii::$app->user->can("/employee/export-data/employee-profile-pdf")) { ?>
		    <?= Html::a('<i class="fa fa-file-pdf-o"></i> '.Yii::t('emp', 'Generate PDF'), ['export-data/employee-profile-pdf', 'eid' => $model->emp_master_id], ['class' => 'btn-sm btn btn-warning', 'id' => 'export-pdf', 'target' => 'blank']) ?>
		<?php } ?>
		</div>
	</h2>
  </div><!-- /.col -->
</div>
</section>

<section class="content edusec-user-profile">
<div class="row">
	<div class="col-md-3 table-responsive edusec-pf-border no-padding edusecArLangCss" style="margin-bottom:15px">
		<div class="col-md-12 text-center">
			<?= Html::img($info->getEmpPhoto($info->emp_photo), ['alt'=>'No Image', 'class'=>'img-circle edusec-img-disp']); ?>
		<div class="photo-edit">
			<?php if(Yii::$app->user->can("/employee/emp-master/emp-photo") && (Yii::$app->session->get('emp_id') == $_REQUEST['id'])  || in_array('SuperAdmin',$admin) || Yii::$app->user->can("updateAllEmpInfo")) { ?>
			<?= Html::a('<i class="fa fa-pencil"></i>', ['emp-photo', 'eid'=>$model->emp_master_id], ['class'=>'photo-edit-icon', 'title'=>'Change Profile Picture', 'data-toggle'=>"modal",
'data-target'=>"#basicModal"]) ?>
			<?php } ?>
		</div>
		</div>
		<table class="table table-striped">
			<tr>
				<th><?php echo Yii::t('emp', 'Employee ID'); ?></th>
				<td><?= Html::encode($info->emp_unique_id) ?></td>
			</tr>
			<tr>
				<th><?php echo Yii::t('emp', 'BPUT Regd No.'); ?></th>
				<td><?= Html::encode($info->university_regd_no) ?></td>
			</tr>
			<tr>
				<th><?php echo Yii::t('emp', 'Name'); ?></th>
				<td><?= Html::encode($info->emp_title." ".$info->emp_first_name." ".$info->emp_middle_name." ".$info->emp_last_name) ?></td>
			</tr>
			<tr>
				<th><?php echo Yii::t('emp', 'Department'); ?></th>
				<td><?= $model->empMasterDepartment->emp_department_name ?></td>	
			</tr>
			<tr>
				<th><?php echo Yii::t('emp', 'Designation'); ?></th>
				<td><?= (!empty($model->empMasterDesignation->emp_designation_name) ? $model->empMasterDesignation->emp_designation_name :"") ?></td>			
			</tr>
			<tr>
				<th><?php echo Yii::t('emp', 'Category'); ?></th>
				<td><?= (!empty($model->empMasterCategory->emp_category_name) ? $model->empMasterCategory->emp_category_name : "") ?></td>		
			</tr>
			<tr>
				<th><?= Html::activeLabel($info, 'emp_mobile_no') ?></th>
				<td><?= (!empty($info->emp_mobile_no) ? $info->emp_mobile_no : "" )?></td>
			</tr>	
			<tr>
				<th><?= Html::activeLabel($info, 'emp_email_id') ?></th>
				<td><?= (!empty($info->emp_email_id) ? $info->emp_email_id : "") ?></td>
			</tr>
			
			<tr>
				<th><?php echo Yii::t('emp', 'Status'); ?></th>
				<td>
					<?php
					if($model->emp_master_status_id==1)
					{?>
					<span class="label label-success"><?php echo Yii::t('emp', 'Active'); ?></span>    
					<?php
					}
					else if($model->emp_master_status_id==2)
					{?>
					<span class="label label-danger"><?php echo Yii::t('emp', 'Discontinued'); ?></span>    
					<?php
					}
					else if($model->emp_master_status_id==3)
					{?>
					<span class="label label-warning"><?php echo Yii::t('emp', 'Inactive'); ?></span>    
					<?php
					}
					else if($model->emp_master_status_id==4)
					{?>
					<span class="label label-info"><?php echo Yii::t('emp', 'On Leave'); ?></span>    
					<?php
					}
					else if($model->emp_master_status_id==5)
					{?>
					<span class="label label-info"><?php echo Yii::t('emp', 'On Leave'); ?></span>    
					<?php
					}
					else if($model->emp_master_status_id==6)
					{?>
					<span class="label label-info"><?php echo Yii::t('emp', 'On Deputation'); ?></span>    
					<?php
					}
					else if($model->emp_master_status_id==7)
					{?>
					<span class="label label-info"><?php echo Yii::t('emp', 'On Deputation'); ?></span>    
					<?php
					}
					else if($model->emp_master_status_id==8)
					{?>
					<span class="label label-info"><?php echo Yii::t('emp', 'Allowed Late Arrival'); ?></span>    
					<?php
					}
					else
					{?>
					<span class="label label-success"><?php echo Yii::t('emp', 'Active'); ?></span>    
					<?php
					}
					?>
					
					
					
				</td>
			</tr>
		</table>
	</div>

	<div class="col-md-9 profile-data">
		<ul class="nav nav-tabs responsive" id = "profileTab">
			<li class="active" id = "personal-tab"><a href="#personal" data-toggle="tab"><i class="fa fa-street-view"></i> <?php echo Yii::t('emp', 'Personal'); ?></a></li>
			<li id = "guardians-tab"><a href="#guardians" data-toggle="tab"><i class="fa fa-user"></i> <?php echo Yii::t('emp', 'Guardians'); ?></a></li>
			<li id = "address-tab"><a href="#address" data-toggle="tab"><i class="fa fa-home"></i> <?php echo Yii::t('emp', 'Address'); ?></a></li>
			<li id = "academic-tab"><a href="#otherinfo" data-toggle="tab"><i class="fa fa-cogs"></i>
 <?php echo Yii::t('emp', 'Other Info'); ?></a></li>
			<li id = "documents-tab"><a href="#documents" data-toggle="tab"><i class="fa fa-file-text"></i> <?php echo Yii::t('emp', 'Documents'); ?></a></li>
			<li id = "health-tab"><a href="#health" data-toggle="tab"><i class="fa fa-heartbeat"></i> <?php echo Yii::t('emp', 'Health'); ?></a></li>
		</ul>
		 <div id='content' class="tab-content responsive">
			<div class="tab-pane active" id="personal">
				<?= $this->render('_tab_emp_personal',['info' => $info, 'model' => $model])?>	
			</div>
			<div class="tab-pane" id="guardians">
				<?= $this->render('_tab_emp_guardian', ['info'=>$info, 'model'=>$model]) ?>	
			</div>
			<div class="tab-pane" id="address">
				<?= $this->render('_tab_emp_address', ['address' => $address, 'model'=>$model]) ?>	
			</div>
			<div class="tab-pane" id="otherinfo">
				<?= $this->render('_tab_emp_otherinfo', ['info' => $info, 'model' => $model]) ?>	
			</div>
			<div class="tab-pane" id="documents">
				<?= $this->render('_tab_emp_documents', ['emp_docs' => $emp_docs, 'model'=>$model]) ?>	
			</div>
			<div class="tab-pane" id="health">
				<?= $this->render('_tab_emp_health', ['health' => $health, 'model'=>$model]) ?>	
			</div>
		</div>
	</div>
     </div> <!---End Row Div--->
</section>

<?php $this->registerJs("(function($) {
      fakewaffle.responsiveTabs(['xs', 'sm']);
  })(jQuery);", yii\web\View::POS_END, 'responsive-tab'); ?>


<!-- below code is for fancy box for update photo -->
<div class="modal fade" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">            
            <div class="modal-body">
            </div>
        </div>
    </div>
</div>
