<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $model app\modules\academics\models\Subjectteacher */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="col-xs-12 col-lg-12">
  <div class="<?php echo $model->isNewRecord ? 'box-success' : 'box-info'; ?> box view-item col-xs-12 col-lg-12">
<div class="leaveapply-form">
  <?php
if($this->context->action->id == 'update'){
        $facbookInfo = app\modules\employee\models\Vacancycreate::find()->where([ 'vacancy_id' => $_REQUEST['id']])->one();

    if (isset($facbookInfo)){
        if ($facbookInfo->eid == \Yii::$app->user->identity->id){
        $action = ['update', 'id'=>$_REQUEST['id']];
    }
    else $action = ['Reset'];
    }
        }
    else
        $action = ['create'];

    //if($this->context->action->id == 'update')
      //  $action = ['update', 'id'=>$_REQUEST['id']];
    //else
      //  $action = ['create'];
    
    
$bofficerInfo = app\modules\employee\models\EmpMaster::find()->where([ 'emp_master_user_id' => \Yii::$app->user->identity->id])->one();
if (isset($bofficerInfo)){
if ($bofficerInfo->immediate_higher_officer <> '0'){ 
?>
    <?php $form = ActiveForm::begin([
            'id' => 'leaveapply-form',
            'action' => $action,
            'enableAjaxValidation' => true,
                ]); ?>
<?= $form->field($model, 'forwarded_by')->hiddenInput(['value'=> $bofficerInfo->immediate_higher_officer])->label(false);?>
<?= $form->field($model, 'entry_by_hr')->hiddenInput(['value'=> '0'])->label(false);?>
<div class="col-xs-12 col-lg-12 no-padding">
    <div class="col-sm-3">
         <?php echo $form->field($model,'vacancy_jobrole',['inputOptions'=>[ 'class'=>'form-control'] ])->dropDownList(ArrayHelper::map(\app\modules\employee\models\EmpDesignation::find()->orderBy(['(emp_designation_name)' => SORT_ASC])->all(),'emp_designation_id','emp_designation_name'),
            [
                    'prompt'=> Yii::t('academics', '--- Select ---'),
                  
                ]       
                ); 
                ?>
    </div>
    <div class="col-sm-2">
        <?= $form->field($model, 'noofvacancies',['inputOptions'=>[ 'class'=>'form-control', 'placeholder'=>Yii::t('academics', 'Persons Required')] ])->textInput(['maxlength' => 3]); ?>
    </div>
    
    <div class="col-sm-2">
              <?= $form->field($model, 'required_date')->widget(yii\jui\DatePicker::className(),
                [
            'model'=>$model,
            'attribute'=>'required_date', 
                'clientOptions' =>[
                    'dateFormat' => 'dd-mm-yyyy',
                    'changeMonth'=> true,
            'yearRange'=>'1900:'.(date('Y')),
                    'changeYear'=> false,
            'readOnly'=>true,
                    'autoSize'=>true,],
                'options'=>[
            'class'=>'form-control',
                     ],]) ?>        
   
    </div>
   
    <div class="col-sm-5">
        <?= $form->field($model, 'vacancy_desired_qualification',['inputOptions'=>[ 'class'=>'form-control', 'placeholder'=>Yii::t('academics', 'Desired Qualification and Skill Set')] ])->textInput(['maxlength' => 2000]); ?>
    </div>
 
</div>
    <div class="form-group col-xs-12 col-sm-6 col-lg-4 no-padding edusecArLangCss">
    <div class="col-xs-6">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('academics', 'Create') : Yii::t('academics', 'Update'), ['class' => $model->isNewRecord  ? 'btn btn-block btn-success' : 'btn btn-block btn-info']) ?>
    </div>
    <div class="col-xs-6">
    <?= Html::resetButton(Yii::t('academics', 'Reset'),['class' => 'btn btn-default btn-block']) ?>
    </div>
     </div>

    <?php ActiveForm::end(); ?>
</div>
  </div>
</div>
<?php
}
else
{

    echo "<font color='red'>You can't raise new vacancy as your Branch Officer data not found. Please contact HR Section</font>";
}
}
else
{

    echo "<font color='red'>You can't raise new vacancy as your Branch Officer data not found. Please contact HR Section</font>";
}
?>



