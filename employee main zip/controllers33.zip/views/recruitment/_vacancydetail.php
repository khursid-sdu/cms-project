<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
use kartik\grid\GridView;
use kartik\editable\Editable;
use app\modules\employee\models\Vacancycreaterecommender;
use app\modules\employee\models\VacancycreaterecommenderSearch;
/* @var $this yii\web\View */
/* @var $model app\modules\academics\models\Subjectteacher */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="col-xs-12 col-lg-12">
  <div class="<?php echo $model->isNewRecord ? 'box-success' : 'box-info'; ?> box view-item col-xs-12 col-lg-12">
<div class="leaveapply-form">
  <?php
 
  
  

$provider = new \yii\data\ActiveDataProvider([
    'query' => Vacancycreaterecommender::find()->where(['vacancy_master_id'=>$model->vacancy_id])->orderBy(['(v_id)' => SORT_DESC]),
    'pagination' => [
        'pageSize' => 50,
    ],
]);


?>
   
<div class="col-xs-12" style="padding-top: 10px;">
    <div class="box">
       <div class="box-header">
<style>
.truncate {
   max-width: 200px !important;
   overflow: hidden;
   white-space: nowrap;
   text-overflow: ellipsis;
}

.truncate:hover{
   overflow: visible;
   white-space: normal;
   width: auto;
}
</style>
       </div><!-- /.box-header -->
    <div class="box-body table-responsive">
     <div class="facultybooks-index">
      
<?= GridView::widget([
          'dataProvider' => $provider,
          //'filterModel' => $searchModel,
          'summary'=>'',
          'columns' => [
              ['class' => 'yii\grid\SerialColumn'],
         // 'l_id',
         // 'leave_master_id',
           [
          'attribute' => 'forwarded_by',
          'value' => function ($model) {                      
        return $model->facultymentorBy->emp_first_name.' '.$model->facultymentorBy->emp_middle_name.' '.$model->facultymentorBy->emp_last_name;
    },
 
            ],
        
          [
          'attribute' => 'forwarded_to',
          'value' => function ($model) {
          if (isset($model->facultymentorxBy)){                      
        return $model->facultymentorxBy->emp_first_name.' '.$model->facultymentorxBy->emp_middle_name.' '.$model->facultymentorxBy->emp_last_name;
      }
       else {                      
        return '-';
      }
    },
          ],
          

          [
          'label' => Yii::t('mentor', 'Remarks'),
          'attribute' => 'forwarder_remarks',
          'value' => 'forwarder_remarks',
          'contentOptions' => ['style'=>'max-width: 400px;','class' => 'truncate'],
          ],
           [
          'label' => Yii::t('mentor', 'Date and Time'),
          'attribute' => 'created_at',
          'value' => function ($model, $key, $index, $widget) { 
            if ($model->created_at <> '0000-00-00 00:00:00'){
                    return date("d-m-Y h:m:s", strtotime($model->created_at));}
            else {return '-';}
                },
          ],
         
          ['label' => Yii::t('academics', 'Status'),
          'attribute' => 'is_status',
          'format' => 'raw',
          'value' => function ($model) {if ($model->is_status=='1' or $model->is_status=='3'){return '<i class="fa fa-thumbs-up" aria-hidden="true" style="color:green"></i>';}
          else if ($model->is_status=='0'){return '<i class="fa fa-spinner" aria-hidden="true"></i>';}
          else if ($model->is_status=='2'){return '<i class="fa fa-thumbs-down" aria-hidden="true" style="color:red"></i>';}
          else {return 'Status Unknown';}
            },
          ],
            
        [
         'class' => 'app\components\CustomActionColumn', 'template'=>'', 'buttons'=> [],
        ],
          ],
      ]); ?>
    
       
       </div>
     </div>
  </div>
</div>

</div>
  </div>
</div>



