<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use app\modules\employee\models\EmpDepartment;
use app\modules\employee\models\EmpInfo;
use yii\helpers\Url;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\modules\employee\models\EmpMasterSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('emp', 'Manage Employees');
$this->params['breadcrumbs'][] = ['label' => Yii::t('emp', 'Employee'), 'url' => ['default/index']];
$this->params['breadcrumbs'][] = $this->title;

$info = new EmpInfo();
?>
<div class="col-xs-12">
  <div class="col-lg-8 col-sm-8 col-xs-12 no-padding edusecArLangCss"><h3 class="box-title"><i class="fa fa-th-list"></i> 
	<?php echo $this->title ?></h3></div>
  <div class="col-lg-4 col-sm-4 col-xs-12 no-padding" style="padding-top: 20px !important;">
	<div class="col-xs-4 left-padding">
	<?php if(Yii::$app->user->can("/employee/emp-master/create")) { ?>
            <?= Html::a(Yii::t('emp', 'ADD'), ['create'], ['class' => 'btn btn-block btn-success']) ?>
	<?php } ?>
	</div>
	<div class="col-xs-4 left-padding">
	<?php if(Yii::$app->user->can("/export-data/export-to-pdf")) { ?>
	    <?= Html::a(Yii::t('emp', 'PDF'), ['/export-data/export-to-pdf', 'model'=>get_class($searchModel)], ['class' => 'btn btn-block btn-warning', 'target'=>'_blank']) ?>
	<?php } ?>
	</div>
	<div class="col-xs-4 left-padding">
	<?php if(Yii::$app->user->can("/export-data/export-excel")) { ?>
	    <?= Html::a(Yii::t('emp', 'EXCEL'), ['/export-data/export-excel', 'model'=>get_class($searchModel)], ['class' => 'btn btn-block btn-primary', 'target'=>'_blank']) ?>
	<?php } ?>
	</div>
  </div>
</div>

<div class="col-xs-12" style="padding-top: 10px;">
    <div class="box">
        <div class="box-header">

        </div><!-- /.box-header -->
     <div class="box-body table-responsive">
	
<div class="emp-master-index">
<?php $visible = Yii::$app->user->can("/employee/emp-master/view") ? true : false; ?>
 <?php Pjax::begin([ 'enablePushState' => false ]); ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
	'summary'=>'',
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
		[
			'label' => Yii::t('emp', 'Employee ID'),
			'attribute' => 'emp_unique_id',
			'value' => 'empMasterEmpInfo.emp_unique_id',
 	        ],
 	        [
			'label' => Yii::t('emp', 'Employee Code'),
			'attribute' => 'emp_master_user_id',
			'value' => 'emp_master_user_id',
 	        ],
 	        [
			'label' => Yii::t('emp', 'Title'),
			'value' => 'empMasterEmpInfo.emp_title',
 	        ],
		[
			'label' => Yii::t('emp', 'First Name'),
			'attribute' => 'emp_first_name',
			'value' => 'empMasterEmpInfo.emp_first_name',
 	        ],
		[
			'label' => Yii::t('emp', 'Middle Name'),
			'attribute' => 'emp_middle_name',
			'value' => 'empMasterEmpInfo.emp_middle_name',
 	        ],
		[
			'label' => Yii::t('emp', 'Last Name'),
			'attribute' => 'emp_last_name',
			'value' => 'empMasterEmpInfo.emp_last_name',
 	        ],
		[
			'label' => Yii::t('emp', 'Department'),
			'attribute' => 'emp_master_department_id',
			'value' => 'empMasterDepartment.emp_department_name',
			'filter' =>ArrayHelper::map(app\modules\employee\models\EmpDepartment::find()->where(['is_status' => 0 ])->all(),'emp_department_id','emp_department_name')
                ],	
		[
			'label' => Yii::t('emp', 'Designation'),
			'attribute' => 'emp_master_designation_id',
			'value' => 'empMasterDesignation.emp_designation_name',
			'filter' => ArrayHelper::map(app\modules\employee\models\EmpDesignation::find()->where(['is_status' => 0 ])->all(),'emp_designation_id','emp_designation_name')
	
                ],
		[
			'label' => Yii::t('emp', 'Category'),
			'attribute' => 'emp_master_category_id',
			'value' => 'empMasterCategory.emp_category_name',
			'filter' => ArrayHelper::map(app\modules\employee\models\EmpCategory::find()->where(['is_status' => 0 ])->all(),'emp_category_id','emp_category_name')
	
                ],
        [
			'label' => Yii::t('emp', 'Status'),
			'attribute' => 'emp_master_status_id',
		'format' => 'raw',
    'value' => function ($model)
    {
        if($model->emp_master_status_id=='1')
         {
          return '<span class="label label-success">Active</span>';
        }
        if($model->emp_master_status_id=='2')
         {
          return '<span class="label label-danger">Discontinued</span>';
        }
        if($model->emp_master_status_id=='3')
        {
            return '<span class="label label-warning">Inactive</span>';
        }
        if($model->emp_master_status_id=='4')
        {
            return '<span class="label label-info">On Leave (<=3 days)</span>';
        }
        if($model->emp_master_status_id=='5')
        {
            return '<span class="label label-info">On Leave (>3 days)</span>';
        }
        if($model->emp_master_status_id=='6')
        {
            return '<span class="label label-info">On Deputation (<=5 days)</span>';
        }
        if($model->emp_master_status_id=='7')
        {
            return '<span class="label label-info">On Deputation (>5 days)</span>';
        }
         if($model->emp_master_status_id=='8')
        {
            return '<span class="label label-info">Allowed Late Arrival</span>';
        }
    },  
    'filter'=>[1 => 'Active', 3 => 'Inactive', 4 => 'On Leave (<=3 days)', 5 => 'On Leave (>3 days)',6=>'On Deputation (<=5 days)',7=>'On Deputation (>5 days)',8=>'Allowed Late Arrival'],
	
                ],
		[
		     	'class' => 'app\components\CustomActionColumn',
			'template' => '{view}{delete}',
			'buttons' => [
				'view' => function ($url, $model) {
				        return ((Yii::$app->user->can("/employee/emp-master/view")) ? Html::a('<span class="glyphicon glyphicon-search"></span>', $url, ['title' => Yii::t('emp', 'View'),]) : '');
				    },
				'delete' => function ($url, $model) {
				        return ((Yii::$app->user->can("/employee/emp-master/delete")) ? Html::a('<span class="glyphicon glyphicon-remove"></span>', $url, ['title' => Yii::t('emp', 'Deactivate'), 'data' => ['confirm' => Yii::t('emp', 'Are you sure you want to delete this item?'),'method' => 'post'],]) : '');
				    }
			],
		     'visible' => $visible,
		],
	],
    ]); ?>
   <?php Pjax::end(); ?>
</div></div></div></div>
