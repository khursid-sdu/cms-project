<?php 
use yii\helpers\Html; 
$this->title = Yii::t('app', 'Employee');
$this->params['breadcrumbs'][] = $this->title;
$this->params['breadcrumbs'][] = Yii::t('app', 'Recruitment and Onboarding');
?>


<div class="box box-default">
   <div class="box-header with-border">
        <h3 class="box-title"><i class="glyphicon glyphicon-cog"></i> <?php echo Yii::t('app', 'Recruitment and Onboarding'); ?></h3>
   </div>
   <div class="box-body">
    <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="edusec-link-box">
                <span class="edusec-link-box-icon bg-aqua"><i class="fa fa-briefcase"></i></span>
                <div class="edusec-link-box-content">
                  <span class="edusec-link-box-text"><?= Html::a(Yii::t('app', 'Job Vacancies'), ['/employee/recruitment/view']);?></span>
                  <span class="edusec-link-box-number"><?= app\modules\employee\models\Vacancycreate::find()->where(['is_status'=>1])->count(); ?></span>
             <span class="edusec-link-box-desc"></span>
              <span class="edusec-link-box-bottom"><?= Html::a('<i class="fa fa-plus-square"></i> '. Yii::t('app', 'Create New'), ['/employee/recruitment/create']); ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
        </div>
<?php
 $checkimmediateofficer = app\modules\employee\models\Vacancycreate::find()->joinWith('checkallOfficer')->where([ 'vacancycreate.is_status' => 0, 'vacancyrecommender.is_status'=> 0, 'vacancyrecommender.forwarded_by'=>Yii::$app->getid->getId()])->all();
if (isset($checkimmediateofficer)){

    if(count($checkimmediateofficer)>0) { 
?>

        <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="edusec-link-box">
                <span class="edusec-link-box-icon bg-aqua"><i class="fa fa-tasks"></i></span>
                <div class="edusec-link-box-content">
                  <span class="edusec-link-box-text"><?= Html::a(Yii::t('app', 'Review/Record Vacancies'), ['/employee/recruitment/review']);?></span>
                  <span class="edusec-link-box-number"><?= app\modules\employee\models\Vacancycreate::find()->joinWith('checkallOfficer')->where([ 'vacancycreate.is_status' => 0, 'vacancyrecommender.is_status'=> 0, 'vacancyrecommender.forwarded_by'=>Yii::$app->getid->getId()])->count(); ?></span>
             <span class="edusec-link-box-desc"></span>
              <span class="edusec-link-box-bottom"></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
        </div>
        
     <?php
     }
    else if(Yii::$app->user->can('/employee/recruitment/record')) {
      ?>
<div class="col-md-4 col-sm-6 col-xs-12">
              <div class="edusec-link-box">
                <span class="edusec-link-box-icon bg-aqua"><i class="fa fa-tasks"></i></span>
                <div class="edusec-link-box-content">
                  <span class="edusec-link-box-text"><?= Html::a(Yii::t('app', 'Review/Record Vacancies'), ['/employee/recruitment/review']);?></span>
                  <span class="edusec-link-box-number"><?= app\modules\employee\models\Vacancycreate::find()->joinWith('checkallOfficer')->where([ 'vacancycreate.is_status' => 0, 'vacancyrecommender.is_status'=> 0, 'vacancyrecommender.forwarded_by'=>Yii::$app->getid->getId()])->count(); ?></span>
             <span class="edusec-link-box-desc"></span>
              <span class="edusec-link-box-bottom"></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
        </div>
<?php
    }
  }
     
     ?>  

        

        


       

        


        
        

    </div> <!-- /. End Row-->
    

</div><!-- /.box-body -->
</div>



