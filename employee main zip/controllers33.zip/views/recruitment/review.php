<?php

use yii\helpers\Html;
use kartik\grid\GridView;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
/* @var $this yii\web\View */
/* @var $searchModel app\models\CitySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('academics', 'Review Vacancies');
$this->params['breadcrumbs'][] = ['label' => Yii::t('academics', 'Employee'), 'url' => ['default/index']];
$this->params['breadcrumbs'][] = ['label' => Yii::t('academics', 'Recruitment & Onboarding'),];
$this->params['breadcrumbs'][] = $this->title;
?>

<?php 
if(Yii::$app->user->can('/employee/recruitment/record') ) {


$action = ['create'];
$form = ActiveForm::begin([
            'id' => 'leaveapply-form',
            'action' => $action,
            'enableAjaxValidation' => true,
                ]); ?>
<?= Yii::$app->session->getFlash('msg') ?>
<div class="col-xs-12 col-lg-12 no-padding">
<?= $form->field($model, 'entry_by_hr')->hiddenInput(['value'=> '1'])->label(false);?>
    <div class="col-sm-3">
         <?php echo $form->field($model,'eid',['inputOptions'=>[ 'class'=>'form-control'] ])->dropDownList(ArrayHelper::map(\app\modules\employee\models\EmpInfo::find()->joinWith('empMastersagain')->orderBy(['(emp_first_name)' => SORT_ASC])->all(),'empMastersagain.emp_master_user_id',function($model, $defaultValue) {
        return $model['emp_first_name'].' '.$model['emp_middle_name'].' '.$model['emp_last_name'];
    }),
            [
                    'prompt'=> Yii::t('academics', '--- Select Teacher ---'),
                  
                ]       
                )->label('Requisitioned by'); 
                ?>
    </div>

    <div class="col-sm-3">
         <?php echo $form->field($model,'vacancy_jobrole',['inputOptions'=>[ 'class'=>'form-control'] ])->dropDownList(ArrayHelper::map(\app\modules\employee\models\EmpDesignation::find()->orderBy(['(emp_designation_name)' => SORT_ASC])->all(),'emp_designation_id','emp_designation_name'),
            [
                    'prompt'=> Yii::t('academics', '--- Select ---'),
                  
                ]       
                ); 
                ?>
    </div>
    <div class="col-sm-2">
              <?= $form->field($model, 'required_date')->widget(yii\jui\DatePicker::className(),
                [
            'model'=>$model,
            'attribute'=>'required_date', 
                'clientOptions' =>[
                    'dateFormat' => 'dd-mm-yyyy',
                    'changeMonth'=> true,
            'yearRange'=>'1900:'.(date('Y')),
                    'changeYear'=> false,
            'readOnly'=>true,
                    'autoSize'=>true,],
                'options'=>[
            'class'=>'form-control',
                     ],]) ?>           
   
    </div>
    <div class="col-sm-2">
            <?= $form->field($model, 'noofvacancies',['inputOptions'=>[ 'class'=>'form-control', 'placeholder'=>Yii::t('academics', 'Persons Required')] ])->textInput(['maxlength' => 3]); ?>
    </div>
    <div class="col-sm-2">
        <?= $form->field($model, 'vacancy_desired_qualification',['inputOptions'=>[ 'class'=>'form-control', 'placeholder'=>Yii::t('academics', 'Desired Qualification and Skill Set')] ])->textInput(['maxlength' => 2000]); ?>
    </div>
 
</div>
    <div class="form-group col-xs-12 col-sm-6 col-lg-4 no-padding edusecArLangCss">
    <div class="col-xs-6">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('academics', 'Save') : Yii::t('academics', 'Update'), ['class' => $model->isNewRecord  ? 'btn btn-block btn-success' : 'btn btn-block btn-info']) ?>
    </div>
    <div class="col-xs-6">
    <?= Html::resetButton(Yii::t('academics', 'Reset'),['class' => 'btn btn-default btn-block']) ?>
    </div>
     </div>

    <?php ActiveForm::end(); 
}
    ?>


<div class="col-xs-12">
  <div class="col-lg-4 col-sm-4 col-xs-12 no-padding edusecArLangCss"><h3 class="box-title"><i class="fa fa-th-list"></i> 
    <?php echo $this->title ?></h3></div>
      <div class="col-lg-4 col-sm-4 col-xs-12 no-padding" style="padding-top: 20px !important;">
     <div class="col-xs-4 left-padding edusecArLangHide">
       <style>
.truncate {
   max-width: 200px !important;
   overflow: hidden;
   white-space: nowrap;
   text-overflow: ellipsis;
}

.truncate:hover{
   overflow: visible;
   white-space: normal;
   width: auto;
}
</style>
     </div>
      
       </div>
</div>

<div class="col-xs-12" style="padding-top: 10px;">
    <div class="box">
       <div class="box-header">

       </div><!-- /.box-header -->
    <div class="box-body table-responsive">
     <div class="courseoutcome-index">
      
<?= GridView::widget([
          'dataProvider' => $dataProvider,
          'filterModel' => $searchModel,
    'summary'=>'',
          'columns' => [
                [
    'class'=>'kartik\grid\ExpandRowColumn',
    'width'=>'50px',
    'value'=>function ($model, $key, $index, $column) {
        return GridView::ROW_COLLAPSED;
    },
    'detail'=>function ($model, $key, $index, $column) {
        return Yii::$app->controller->renderPartial('_reviewform', ['model'=>$model]);
    },
    'headerOptions'=>['class'=>'kartik-sheet-style'], 
    'expandOneOnly'=>'true',
],
              ['class' => 'yii\grid\SerialColumn'],

           ['label' => Yii::t('mentor', 'Requisitioned By'),
          'attribute' => 'eid',
          'value' => function ($model) {                      
        return $model->facultyxmentorBy->emp_first_name.' '.$model->facultyxmentorBy->emp_middle_name.' '.$model->facultyxmentorBy->emp_last_name;
    },
     'filter' => ArrayHelper::map(app\modules\employee\models\EmpInfo::find()->joinWith('empMastersagain')->orderBy(['(emp_first_name)' => SORT_ASC])->all(), 'empMastersagain.emp_master_user_id', 
function($model, $defaultValue) {
        return $model['emp_first_name'].' '.$model['emp_middle_name'].' '.$model['emp_last_name'];
    }
    )
 
            ],
            [
      'label' => Yii::t('emp', 'Designation'),
      'attribute' => 'vacancy_jobrole',
      'value' => 'empMasterDesignation.emp_designation_name',
      'filter' => ArrayHelper::map(app\modules\employee\models\EmpDesignation::find()->where(['is_status' => 0 ])->all(),'emp_designation_id','emp_designation_name')
  
                ],
                ['label' => Yii::t('academics', 'Persons Required'),
          'attribute' => 'noofvacancies',
          'value' => 'noofvacancies',
          ],
        
        ['label' => Yii::t('academics', 'Desired Qualification'),
          'attribute' => 'vacancy_desired_qualification',
          'value' => 'vacancy_desired_qualification',
          'contentOptions' => ['style'=>'max-width: 400px;','class' => 'truncate'],
          ],
        ['label' => Yii::t('mentor', 'Date Required'),
          'attribute' => 'required_date',
          'value' => function ($model, $key, $index, $widget) { 
                    return date("d-m-Y", strtotime($model->required_date));
                },
          'filter' => \yii\jui\DatePicker::widget([
                'model'=>$searchModel,
                'attribute'=>'required_date',
                'clientOptions' =>[
                    'dateFormat' => 'dd-mm-yyyy',
                    'changeMonth'=> true,
                    'changeYear'=> true,
        'defaultValue'=>null,
        'yearRange'=>'1900:'.(date('Y')+1),
        'defaultDate'=> null,],
           'options'=>[
        'id' => 'required_date',
                    'value' => NULL,
        'class'=>'form-control',
                     ],
            ]),
      'format' => 'html',
           
            ],
          
           
        ['label' => Yii::t('academics', 'Status'),
          'attribute' => 'is_status',
          'format' => 'raw',
          'value' => function ($model) {if ($model->is_status=='1'){return '<i class="fa fa-thumbs-up" aria-hidden="true" style="color:green"></i>';}
          else if ($model->is_status=='0'){return '<i class="fa fa-spinner" aria-hidden="true"></i>';}
          else if ($model->is_status=='2'){return '<i class="fa fa-thumbs-down" aria-hidden="true" style="color:red"></i>';}
          else {return 'Status Unknown';}
            },
          'filter'=>['0'=>'Under Processing', '1'=>'Approved', '2'=>'Disapproved']
        ],
       
       

       [
         'class' => 'app\components\CustomActionColumn', 'template'=>'', 'buttons'=> [],
        ],
          ],
      ]); ?>
    
       
       </div>
     </div>
  </div>
</div>
