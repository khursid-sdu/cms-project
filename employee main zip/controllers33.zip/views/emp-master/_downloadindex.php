<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $searchModel app\modules\fees\models\BankMasterSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('fees', 'Employee Certificates and Documents');
$this->params['breadcrumbs'][] = ['label' => Yii::t('fees', 'Employee'), 'url' => ['default/index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="col-xs-12">
  <div class="col-lg-8 col-sm-8 col-xs-12 no-padding edusecArLangCss"><h3 class="box-title"><i class="fa fa-th-list"></i> <?php echo "Employee Certificates and Documents"; ?></h3></div>
  <div class="col-lg-4 col-sm-4 col-xs-12 no-padding" style="padding-top: 20px !important;">
	<div class="col-xs-4 left-padding edusecArLangHide">
	</div>
	<div class="col-xs-4 left-padding">

	</div>

	</div>
  </div>


<div class="col-xs-12" style="padding-top: 10px;">
   <div class="box">
      <div class="box-body table-responsive">
	<div class="bank-master-index">
	    <?= GridView::widget([
		'dataProvider' => $dataProvider,
		'filterModel' => $searchModel,
		'summary' => '',
		'columns' => [
		    ['class' => 'yii\grid\SerialColumn'],
           
            ['label' => Yii::t('mentor', 'Employee Name'),
          'attribute' => 'emp_docs_emp_master_id',
          
          'value' => function ($model) {                      
        return $model->empDocsEmpMaster->empMasterEmpInfo->emp_first_name.' '.$model->empDocsEmpMaster->empMasterEmpInfo->emp_middle_name.' '.$model->empDocsEmpMaster->empMasterEmpInfo->emp_last_name;
    },
          'filter' => ArrayHelper::map(app\modules\employee\models\EmpMasterAll::find()->joinWith('empMasterEmpInfo')->orderBy(['emp_info.emp_first_name'=>SORT_ASC])->all(), 'emp_master_id', 
function($model, $defaultValue) {
        return $model->empMasterEmpInfo->emp_first_name.' '.$model->empMasterEmpInfo->emp_middle_name.' '.$model->empMasterEmpInfo->emp_last_name;
    }
    )
          ],
          
          ['label' => Yii::t('mentor', 'Document Name'),
          'attribute' => 'emp_docs_category_id',
          
          'value' => function ($model) {                      
        return $model->empDocsCategory->doc_category_name;
    },
          'filter' => ArrayHelper::map(app\models\DocumentCategory::find()->orderBy(['doc_category_name'=>SORT_ASC])->all(), 'doc_category_id','doc_category_name')
          ],
           
              ['label' => Yii::t('mentor', 'Date Uploaded'),
          'attribute' => 'emp_docs_submited_at',
          'value' => function ($model, $key, $index, $widget) { 
                    return date("d-m-Y", strtotime($model->emp_docs_submited_at));
                },
          'filter' => \yii\jui\DatePicker::widget([
                'model'=>$searchModel,
                'attribute'=>'emp_docs_submited_at',
                'clientOptions' =>[
                    'dateFormat' => 'dd-mm-yyyy',
                    'changeMonth'=> true,
                    'changeYear'=> true,
        'defaultValue'=>null,
        'yearRange'=>'1900:'.(date('Y')+1),
        'defaultDate'=> null,],
           'options'=>[
        'id' => 'emp_docs_submited_at',
                    'value' => NULL,
        'class'=>'form-control',
                     ],
            ]),
      'format' => 'html',
           
            ],
           
             
          ['label' => Yii::t('mentor', 'Download'),
         // 'attribute' => 'emp_docs_path',
            'format' => 'raw',
            'value' => function($model) {
                
                if (isset($model->emp_docs_path))
                {
                    
                        return Html::a('<span class = "glyphicon glyphicon-paperclip"></span>&nbsp;&nbsp;Download', ['docs-download', 'emp_doc_id' => $model->emp_docs_id,], ['class' => 'btn-sm btn btn-block btn-primary', 'title' => '', 'data' => ['method' => 'post']]);
                           
                    
                }
                else
                {
                    return '-';
                }
            
                
              },
          
          ],
          
           
		    
		    ['class' => 'app\components\CustomActionColumn', 'template' => ''],
		],
	    ]); ?>
        </div>
     </div>
   </div>
</div>
