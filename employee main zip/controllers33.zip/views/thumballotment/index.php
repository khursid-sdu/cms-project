<?php

use yii\helpers\Html;
use kartik\grid\GridView;
use yii\helpers\ArrayHelper;
use kartik\editable\Editable;
/* @var $this yii\web\View */
/* @var $searchModel app\models\CitySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('mentor', 'Manage Employee Thumb ID');
$this->params['breadcrumbs'][] = ['label' => Yii::t('mentor', 'Employee'), 'url' => ['default/index']];
$this->params['breadcrumbs'][] = ['label' => Yii::t('mentor', 'Manage Employee Thumb ID')];

?>
 
<div class="col-xs-12">
  <div class="col-lg-4 col-sm-4 col-xs-12 no-padding edusecArLangCss"><h3 class="box-title"><i class="fa fa-th-list"></i> 
    <?php echo $this->title ?></h3></div>
      <div class="col-lg-4 col-sm-4 col-xs-12 no-padding" style="padding-top: 20px !important;">
     <div class="col-xs-4 left-padding edusecArLangHide">
      
     </div>
         <div class="col-xs-4 left-padding">
       <?= Html::a(Yii::t('stu', 'EXCEL'), ['/export-data/export-excel', 'model'=>get_class($searchModel)], ['class' => 'btn btn-block btn-primary', 'target'=>'_blank']) ?>
       </div>
       </div>
</div>

<div class="col-xs-12" style="padding-top: 10px;">
    <div class="box">
       <div class="box-header">

       </div><!-- /.box-header -->
    <div class="box-body table-responsive">
     <div class="mentorallotment-index">
      
 <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

           [
			'label' => Yii::t('emp', 'Employee ID'),
			'attribute' => 'emp_unique_id',
			],
			
			[
			'label' => Yii::t('emp', 'Title'),
			'attribute' => 'emp_title',
			],
		[
			'label' => Yii::t('emp', 'First Name'),
			'attribute' => 'emp_first_name',
			],
		[
			'label' => Yii::t('emp', 'Middle Name'),
			'attribute' => 'emp_middle_name',
			],
		[
			'label' => Yii::t('emp', 'Last Name'),
			'attribute' => 'emp_last_name',
			],
 	        
 	        [
			'label' => Yii::t('emp', 'Department'),
			'attribute' => 'emp_master_department_id_temp',
			'value' => 'empDeptagain.emp_department_name',
			'filter' =>ArrayHelper::map(app\modules\employee\models\EmpDepartment::find()->where(['is_status' => 0 ])->all(),'emp_department_id','emp_department_name')
                ],	
[
			'label' => Yii::t('emp', 'Designation'),
			'attribute' => 'emp_master_designation_id_temp',
			'value' => 'empDesignationagain.emp_designation_name',
			'filter' => ArrayHelper::map(app\modules\employee\models\EmpDesignation::find()->where(['is_status' => 0 ])->all(),'emp_designation_id','emp_designation_name')
	
                ],
        
            [
    'class'=>'kartik\grid\EditableColumn',
    'attribute'=>'emp_thumb',
    'format' => 'raw',
    'value' => 'emp_thumb',
        
    'editableOptions'=>[
        'header'=>'Thumb ID',
        'formOptions' => ['action' => ['studentthumbupdate']],
        'asPopover' => true,
        'format' => Editable::FORMAT_BUTTON,
        'options' => ['class'=>'form-control', 'placeholder'=>'Thumb ID...']
    ],
    'hAlign'=>'middle',
    'vAlign'=>'middle',
    'width'=>'35%',
   
],
            
       

            ['class' => 'yii\grid\ActionColumn','template'=>''],
        ],
    ]); ?>
    
       
       </div>
     </div>
  </div>
</div>

