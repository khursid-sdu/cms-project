<?php

use yii\helpers\Html;
use kartik\grid\GridView;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model app\models\Country */

$this->title = Yii::t('app', 'Update Vacancy');
$this->params['breadcrumbs'][] = Yii::t('app', 'Employee');
$this->params['breadcrumbs'][] = Yii::t('app', 'Recruitment and Onboarding');
$this->params['breadcrumbs'][] = $this->title;

?>

<div class="col-xs-12">
  <div class="col-lg-12 col-sm-12 col-xs-12 no-padding"><h3 class="box-title"><i class="fa fa-plus"></i> <?php echo Yii::t('app', 'Update Vacancy') ?></h3></div>
</div>

  <div class="country-create">
    <?= $this->render('_form', [
        'model' => $model,
	
    ]) ?>

  </div>

  <div class="col-xs-12">
  <div class="col-lg-4 col-sm-4 col-xs-12 no-padding edusecArLangCss"><h3 class="box-title"><i class="fa fa-th-list"></i> 
    <?php echo "List of Vacancies created by You" ?></h3></div>
      <div class="col-lg-4 col-sm-4 col-xs-12 no-padding" style="padding-top: 20px !important;">
     <div class="col-xs-4 left-padding edusecArLangHide">
       
     </div>
      <div class="col-xs-4 left-padding">
        <?= Html::a(Yii::t('academics', 'PDF'), ['export-data/export-to-pdf', 'model'=>get_class($searchModel)], ['class' => 'btn btn-block btn-warning', 'target'=>'_blank']) ?>
      </div>
       <div class="col-xs-4 left-padding">
        <?= Html::a(Yii::t('academics', 'EXCEL'), ['export-data/export-excel', 'model'=>get_class($searchModel)], ['class' => 'btn btn-block btn-primary', 'target'=>'_blank']) ?>
       </div>
       </div>
</div>

<div class="col-xs-12" style="padding-top: 10px;">
    <div class="box">
       <div class="box-header">
<style>
.truncate {
   max-width: 200px !important;
   overflow: hidden;
   white-space: nowrap;
   text-overflow: ellipsis;
}

.truncate:hover{
   overflow: visible;
   white-space: normal;
   width: auto;
}
</style>
       </div><!-- /.box-header -->
    <div class="box-body table-responsive">
     <div class="courseoutcome-index">
      
<?= GridView::widget([
          'dataProvider' => $dataProvider,
          'filterModel' => $searchModel,
    'summary'=>'',
          'columns' => [
                  [
    'class'=>'kartik\grid\ExpandRowColumn',
    'width'=>'50px',
    'value'=>function ($model, $key, $index, $column) {
        return GridView::ROW_COLLAPSED;
    },
    'detail'=>function ($model, $key, $index, $column) {
        return Yii::$app->controller->renderPartial('_vacancydetail', ['model'=>$model]);
    },
    'headerOptions'=>['class'=>'kartik-sheet-style'], 
    'expandOneOnly'=>'true',
],
              ['class' => 'yii\grid\SerialColumn'],
              [
      'label' => Yii::t('emp', 'Designation'),
      'attribute' => 'vacancy_jobrole',
      'value' => 'empMasterDesignation.emp_designation_name',
      'filter' => ArrayHelper::map(app\modules\employee\models\EmpDesignation::find()->where(['is_status' => 0 ])->all(),'emp_designation_id','emp_designation_name')
  
                ],
              
              'noofvacancies',
         ['label' => Yii::t('mentor', 'Requirement Date'),
          'attribute' => 'required_date',
          'value' => function ($model, $key, $index, $widget) { 
                    return date("d-m-Y", strtotime($model->required_date));
                },
          'filter' => \yii\jui\DatePicker::widget([
                'model'=>$searchModel,
                'attribute'=>'required_date',
                'clientOptions' =>[
                    'dateFormat' => 'dd-mm-yyyy',
                    'changeMonth'=> true,
                    'changeYear'=> true,
        'defaultValue'=>null,
        'yearRange'=>'1900:'.(date('Y')+1),
        'defaultDate'=> null,],
           'options'=>[
        'id' => 'required_date',
                    'value' => NULL,
        'class'=>'form-control',
                     ],
            ]),
      'format' => 'html',
           
            ],
         
         
       
        ['label' => Yii::t('academics', 'Desired Qualification'),
          'attribute' => 'vacancy_desired_qualification',
          'value' => 'vacancy_desired_qualification',
          'contentOptions' => ['style'=>'max-width: 400px;','class' => 'truncate'],
          ],
        ['label' => Yii::t('academics', 'Status'),
          'attribute' => 'is_status',
          'format' => 'raw',
          'value' => function ($model) {if ($model->is_status=='1'){return '<i class="fa fa-thumbs-up" aria-hidden="true" style="color:green"></i>';}
          else if ($model->is_status=='0'){return '<i class="fa fa-spinner" aria-hidden="true"></i>';}
          else if ($model->is_status=='2'){return '<i class="fa fa-thumbs-down" aria-hidden="true" style="color:red"></i>';}
          else {return 'Status Unknown';}
            },
          'filter'=>['0'=>'Under Processing', '1'=>'Approved', '2'=>'Disapproved']
        ],
       'advt_published_at',

       [
         'class' => 'app\components\CustomActionColumn', 'template'=>'{update}', 'buttons'=> [ 'update'=> function($url,$model) {
if ($model->is_status == 0 AND $model->eid == \Yii::$app->user->identity->id) {

                    return Html::a( '<span class="glyphicon glyphicon-pencil"></span>', $url);

} 

                },
                ],
        ],
          ],
      ]); ?> 
    
       
       </div>
     </div>
  </div>
</div>
