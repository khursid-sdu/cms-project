<?php

use yii\helpers\Html;
use app\modules\employee\models\EmpDepartment;
use app\modules\employee\models\EmpInfo;
use yii\helpers\Url;
use yii\widgets\Pjax;
use kartik\grid\GridView;
use yii\helpers\ArrayHelper;
use kartik\editable\Editable;
/* @var $this yii\web\View */
/* @var $searchModel app\modules\employee\models\EmpMasterSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('emp', 'Manage Faculty Registration No.');
$this->params['breadcrumbs'][] = ['label' => Yii::t('emp', 'Employee'), 'url' => ['default/index']];
$this->params['breadcrumbs'][] = $this->title;

$info = new EmpInfo();
?>
<div class="col-xs-12">
  <div class="col-lg-8 col-sm-8 col-xs-12 no-padding edusecArLangCss"><h3 class="box-title"><i class="fa fa-th-list"></i> 
	<?php echo $this->title ?></h3></div>
  <div class="col-lg-4 col-sm-4 col-xs-12 no-padding" style="padding-top: 20px !important;">
	<div class="col-xs-4 left-padding">

	</div>
	<div class="col-xs-4 left-padding">

	</div>
	<div class="col-xs-4 left-padding">

	</div>
  </div>
</div>

<div class="col-xs-12" style="padding-top: 10px;">
    <div class="box">
        <div class="box-header">

        </div><!-- /.box-header -->
     <div class="box-body table-responsive">
	
<div class="emp-master-index">
<?php $visible = Yii::$app->user->can("/employee/emp-master/view") ? true : false; ?>
 <?php Pjax::begin([ 'enablePushState' => false ]); ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
	'summary'=>'',
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            
             [
    'class'=>'kartik\grid\EditableColumn',
    'label'=>'University Regd No.',
    'attribute'=>'university_regd_no',
    //'format' => 'raw',
    'value' => 'empMasterEmpInfo.university_regd_no',
    'editableOptions'=>[
        'header'=>'Attendance Serial No',
        'formOptions' => ['action' => ['regdupdate']],
        'asPopover' => false,
        'format' => Editable::FORMAT_BUTTON,
        'options' => ['class'=>'form-control', 'placeholder'=>'Regd No...']
    ],
    'hAlign'=>'middle',
    'vAlign'=>'middle',
    'width'=>'35%',
   
],
	
		[
			'label' => Yii::t('emp', 'First Name'),
			'attribute' => 'emp_first_name',
			'value' => 'emp_first_name',
 	        ],
		[
			'label' => Yii::t('emp', 'Middle Name'),
			'attribute' => 'emp_middle_name',
			'value' => 'emp_middle_name',
 	        ],
		[
			'label' => Yii::t('emp', 'Last Name'),
			'attribute' => 'emp_last_name',
			'value' => 'emp_last_name',
 	        ],
		[
			'label' => Yii::t('emp', 'Department'),
			'attribute' => 'emp_master_department_id_temp',
			'value' => function($model)
			{return app\modules\employee\models\EmpDepartment::findOne(app\modules\employee\models\EmpMaster::findOne(['emp_master_emp_info_id'=>$model->emp_info_id])->emp_master_department_id)->emp_department_name;
			    },
			'filter' =>ArrayHelper::map(app\modules\employee\models\EmpDepartment::find()->where(['is_status' => 0 ])->all(),'emp_department_id','emp_department_name')
                ],	
		[
			'label' => Yii::t('emp', 'Designation'),
			'attribute' => 'emp_master_designation_id_temp',
			'value' => function($model)
			{return app\modules\employee\models\EmpDesignation::findOne(app\modules\employee\models\EmpMaster::findOne(['emp_master_emp_info_id'=>$model->emp_info_id])->emp_master_designation_id)->emp_designation_name;
			    },
			'filter' => ArrayHelper::map(app\modules\employee\models\EmpDesignation::find()->where(['is_status' => 0 ])->all(),'emp_designation_id','emp_designation_name')
	
                ],
                
				
		[
		     	'class' => 'yii\grid\ActionColumn',
			'template' => '',
			     'visible' => $visible,
		],
	],
    ]); ?>
   <?php Pjax::end(); ?>
</div></div></div></div>
