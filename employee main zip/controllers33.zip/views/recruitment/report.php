<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $searchModel app\models\CitySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('academics', 'Resume/ Referred candidate Report');
$this->params['breadcrumbs'][] = ['label' => Yii::t('academics', 'Employee'), 'url' => ['default/index']];
$this->params['breadcrumbs'][] = ['label' => Yii::t('academics', 'Recruitment and Onboarding')];
$this->params['breadcrumbs'][] = $this->title;



?>
 
<div class="col-xs-12">
  <div class="col-lg-8 col-sm-8 col-xs-12 no-padding edusecArLangCss"><h3 class="box-title"><i class="fa fa-th-list"></i> 
    <?php echo $this->title ?> <?php echo "<font color='gray'> (".\app\modules\employee\models\EmpDesignation::findOne(\app\modules\employee\models\Vacancycreate::findOne($_GET['id'])->vacancy_jobrole)->emp_designation_name.")</font>" ?></h3></div>
      <div class="col-lg-4 col-sm-4 col-xs-12 no-padding" style="padding-top: 20px !important;">
     <div class="col-xs-4 left-padding edusecArLangHide">
       
     </div>
      <div class="col-xs-4 left-padding">
        <?= Html::a(Yii::t('academics', 'PDF'), ['export-data/export-to-pdf', 'model'=>get_class($searchModel)], ['class' => 'btn btn-block btn-warning', 'target'=>'_blank']) ?>
      </div>
       <div class="col-xs-4 left-padding">
        <?= Html::a(Yii::t('academics', 'EXCEL'), ['export-data/export-excel', 'model'=>get_class($searchModel)], ['class' => 'btn btn-block btn-primary', 'target'=>'_blank']) ?>
       </div>
       </div>
</div>

<div class="col-xs-12" style="padding-top: 10px;">
    <div class="box">
       <div class="box-header">

       </div><!-- /.box-header -->
    <div class="box-body table-responsive">
     <div class="courseoutcome-index">
      
<?= GridView::widget([
          'dataProvider' => $dataProvider,
          'filterModel' => $searchModel,
    'summary'=>'',
          'columns' => [
              ['class' => 'yii\grid\SerialColumn'],
        'c_name',
        'c_aadhaar',
        'c_mobile',
        ['label' => Yii::t('academics', 'Download Resume'),
        'attribute'=>'resume',
        'format'=>'raw',
        'value' => function ($model) {if ($model->resume!=''){return '<a class="btn-sm btn btn-block btn-primary" href="/index.php?r=employee%2Frecruitment%2Fresume-download&amp;resume_doc_id='.$model->ref_id.'title="" data-method="post"><span class = "glyphicon glyphicon-download"></span></a>';}},
        'filter'=>''
      ],
        
         [
            'label' => Yii::t('academics','Referred by Staff'),
            'attribute' => 'created_by',
            'value' => function ($model) {                      
        return $model->facultyxmentorBy->emp_first_name.' '.$model->facultyxmentorBy->emp_middle_name.' '.$model->facultyxmentorBy->emp_last_name;
    },
          'filter' => ArrayHelper::map(app\modules\employee\models\EmpInfo::find()->joinWith('empMastersagain')->orderBy(['(emp_first_name)' => SORT_ASC])->all(), 'empMastersagain.emp_master_user_id', 
function($model, $defaultValue) {
        return $model['emp_first_name'].' '.$model['emp_middle_name'].' '.$model['emp_last_name'];
    }
    )
              ],

       [
         'class' => 'app\components\CustomActionColumn', 'template'=>'',
        ],
          ],
      ]); ?>
    
       
       </div>
     </div>
  </div>
</div>
