<?php use yii\helpers\Html; ?>
<?php $empSession =  Yii::$app->session->get('emp_id');
$admin = array_keys(Yii::$app->AuthManager->getRolesByUser(Yii::$app->user->id) );
$role = Yii::$app->AuthManager->getRoles();
	
 ?>
<div class="row">
  <div class="col-xs-12">
	<h2 class="page-header">	
	<i class="fa fa-info-circle"></i> <?php echo Yii::t('emp', 'Other Info'); ?>
	<?php if(Yii::$app->user->can("/employee/emp-master/update") && (Yii::$app->session->get('emp_id') == $_REQUEST['id']) || in_array('SuperAdmin',$admin) || Yii::$app->user->can("updateAllEmpInfo")){ ?>
	<div class="<?= (Yii::$app->language == 'ar') ? 'pull-left' : 'pull-right'; ?>"><?= Html::a('<i class="fa fa-pencil-square-o"></i> '.Yii::t('emp', 'Edit'), ['update', 'empid' => $model->emp_master_id, 'tab' => 'otherinfo'], ['class' => 'btn btn-primary btn-sm', 'id' => 'update-data']) ?></div>
	<?php } ?>
	</h2>
  </div><!-- /.col -->
</div>

<div class="row">
	<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_attendance_card_id') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_attendance_card_id) ? $info->emp_attendance_card_id : "" ?></div>
	    </div>
	  
	</div>
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('university_regd_no') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->university_regd_no) ? $info->university_regd_no : "" ?></div>
	    </div>
	  
	</div>
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_aadhaar') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_aadhaar) ? $info->emp_aadhaar : "" ?></div>
	    </div>
	  
	</div>
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_pan') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_pan) ? $info->emp_pan : "" ?></div>
	    </div>
	  
	</div>
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_voter') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_voter) ? $info->emp_voter : "" ?></div>
	    </div>
	  
	</div>
	<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('driving_license') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->driving_license) ? $info->driving_license : "" ?></div>
	    </div>
	  
	</div>
	
	<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_bankaccount_no') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_bankaccount_no) ? $info->emp_bankaccount_no : "" ?></div>
	    </div>
	  
	</div>
	
	<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_bankname') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_bankname) ? $info->emp_bankname : "" ?></div>
	    </div>
	  
	</div>
	
	<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_ifsc') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_ifsc) ? $info->emp_ifsc : "" ?></div>
	    </div>
	  
	</div>
	
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_mother_name') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_mother_name) ? $info->emp_mother_name : "" ?></div>
	    </div>
	  
	</div>
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_reference') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_reference) ? $info->emp_reference : "" ?></div>
	    </div>
	  
	</div>
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_qualification') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_qualification) ? $info->emp_qualification : "" ?></div>
	    </div>
	  
	</div>
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_specialization') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_specialization) ? $info->emp_specialization : "" ?></div>
	    </div>
	  
	</div>
	
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-12 col-xs-12 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_paperpublished') ?></div>
		<div class="col-lg-12 col-xs-12 edusec-profile-text">
		    
		   <?php
		    $mypapers=\app\modules\rd\models\Facultypublication::find()->andWhere(['faculty_name'=>$model->emp_master_user_id])->all();
		    if(isset($mypapers) AND count($mypapers)>0)
		    {
		        echo "<table class ='table-bordered table table-striped'><tr><th>Title of the Paper</th><th>Name of Journal/ Conference/ Workshop/ Symposium</th><th>Volume</th><th>Issue</th><th>Month/Year</th></tr>";
		        foreach($mypapers as $mp_p)
		        {
		            
$dateObj   = DateTime::createFromFormat('!m', $mp_p->pub_month);
$monthName = $dateObj->format('M');
		            echo "<tr><td>".$mp_p->paper_title."</td><td>".$mp_p->name_of."</td><td>".$mp_p->volume."</td><td>".$mp_p->issue."</td><td>".$monthName."/".$mp_p->pub_year."</td></tr>";
		        }
		        echo "</table>";
		    }
		    ?>  
		    
		</div>
	    </div>
	  
	</div>


	<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_bookswritten') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_bookswritten) ? $info->emp_bookswritten : "" ?></div>
	    </div>
	  
	</div>
	
	<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_rndprojects') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_rndprojects) ? $info->emp_rndprojects : "" ?></div>
	    </div>
	  
	</div>
	
	<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_membership') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_membership) ? $info->emp_membership : "" ?></div>
	    </div>
	  
	</div>
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_workshops') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_workshops) ? $info->emp_workshops : "" ?></div>
	    </div>
	  
	</div>
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_national_conferences') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_national_conferences) ? $info->emp_national_conferences : "" ?></div>
	    </div>
	  
	</div>
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_international_conferences') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_international_conferences) ? $info->emp_international_conferences : "" ?></div>
	    </div>
	  
	</div>




		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_languages') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_languages) ? $info->emp_languages : "" ?></div>
	    </div>
	  
	</div>
	
	
		<div class="col-md-12  col-xs-12">
	   <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
		<div class="col-lg-6 col-xs-6 edusec-profile-label edusecArLangCss"><?= $info->getAttributeLabel('emp_hobbies') ?></div>
		<div class="col-lg-6 col-xs-6 edusec-profile-text"><?= ($info->emp_hobbies) ? $info->emp_hobbies : "" ?></div>
	    </div>
	  
	</div>



</div>
